# Flask-SB-Admin2
SB Admin v2.0 template for python framework flask

Installation
------------
```
git clone https://github.com/w84miracle/flask-sb-admin2.git
cd flask-sb-admin2/
./sbadmin.py
```
visit http://127.0.0.1:5000/

Documents
------------
https://github.com/mitsuhiko/flask

https://github.com/BlackrockDigital/startbootstrap-sb-admin-2
